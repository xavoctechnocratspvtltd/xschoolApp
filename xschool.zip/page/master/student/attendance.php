<?php
class page_student_attendance extends Page {
	function init(){
		parent::init();

		

	}
}