<?php

class page_reports_category extends Page {
	function init(){
		parent::init();

	}
}