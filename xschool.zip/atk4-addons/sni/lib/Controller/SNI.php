<?php
namespace sni;
class Controller_SNI extends \AbstractController {
}
