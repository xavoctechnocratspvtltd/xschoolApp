<?php
class Exception_Filestore extends BaseException {
}
