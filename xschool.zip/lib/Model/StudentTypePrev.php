<?php

class Model_StudentTypePrev extends Model_StudentType {
	public $table_alias = 'prev';
}
