<?php

class Model_ClassPrev extends Model_Class {
	public $table_alias='prev_class';
}