<?php

class Button extends View_Button {
	function jsButton(){
		
	}
	
}